local U = require("lib.util")
function handle(r)
    if r.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(r), json.decode(r.payload)
    assert(c.debug_enabled == "true" or c.DebugEnabled == true, "debug SMS provider is disabled")
    if r.capability == "config.validate" then return json.encode({valid = true}) end
    assert(r.capability == "sms.send", "unsupported capability")
    U.required(p.phone); U.required(p.code); U.required(p.templateCode)
    -- Deliberately no delivery and no OTP/phone logging. The app also gates this
    -- first-party plugin with its development-only debug configuration.
    return json.encode({ok = true, simulated = true})
end
