local U = require("lib.util")
local M = {}
local function value_text(value)
    U.required(value); assert(#value <= 128, "SMS parameter too long")
    local i = 1
    while i <= #value do
        local b, width, codepoint = string.byte(value, i), 1, 0
        if b < 128 then codepoint = b
        elseif b >= 194 and b <= 223 then width = 2; codepoint = b - 192
        elseif b >= 224 and b <= 239 then width = 3; codepoint = b - 224
        elseif b >= 240 and b <= 244 then width = 4; codepoint = b - 240
        else error("invalid SMS parameter UTF-8") end
        for offset = 1, width - 1 do
            local next_byte = string.byte(value, i + offset)
            assert(next_byte and next_byte >= 128 and next_byte <= 191, "invalid SMS parameter UTF-8")
            codepoint = codepoint * 64 + next_byte - 128
        end
        assert((width == 1 or (width == 2 and codepoint >= 128) or (width == 3 and codepoint >= 2048) or (width == 4 and codepoint >= 65536)) and codepoint <= 1114111 and not (codepoint >= 55296 and codepoint <= 57343), "invalid SMS parameter UTF-8")
        assert(codepoint >= 32 and not (codepoint >= 127 and codepoint <= 159), "invalid SMS parameter value")
        i = i + width
    end
end
function M.parameters(p)
    U.required(p.phone); U.required(p.templateCode)
    assert(#p.phone == 11 and string.sub(p.phone, 1, 1) == "1" and string.sub(p.phone, 2, 2) >= "3" and string.sub(p.phone, 2, 2) <= "9", "invalid SMS phone")
    for i = 1, #p.phone do local b = string.byte(p.phone, i); assert(b >= 48 and b <= 57, "invalid SMS phone") end
    assert(#p.templateCode <= 128, "SMS template too long")
    for i = 1, #p.templateCode do
        local b = string.byte(p.templateCode, i); assert(b > 32 and b ~= 127, "invalid SMS template")
    end
    if p.parameters == nil then
        U.required(p.code); assert(#p.code == 6, "invalid SMS code")
        for i = 1, #p.code do local b = string.byte(p.code, i); assert(b >= 48 and b <= 57, "invalid SMS code") end
        return {code = p.code}
    end
    assert(p.code == nil and type(p.parameters) == "table", "ambiguous SMS template parameters")
    local count, result = 0, {}
    for key, value in pairs(p.parameters) do
        count = count + 1
        assert(type(key) == "string" and #key >= 1 and #key <= 32, "invalid SMS parameter key")
        for i = 1, #key do
            local b = string.byte(key, i)
            assert((b >= 65 and b <= 90) or (b >= 97 and b <= 122) or (i > 1 and ((b >= 48 and b <= 57) or b == 95)), "invalid SMS parameter key")
        end
        value_text(value)
        result[key] = value
    end
    assert(count >= 1 and count <= 8, "invalid SMS parameter count")
    return result
end
return M
