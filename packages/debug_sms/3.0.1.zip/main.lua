local U = require("lib.util")
local S = require("lib.sms_template")
function handle(r)
    if r.capability == "health" then
        local host_info = U.call("host.describe", {})
        assert(type(host_info.features) == "table" and host_info.features["sms.template-parameters.v1"] == true, "host template SMS support required")
        return json.encode({ok = true})
    end
    local c, p = U.config(r), json.decode(r.payload)
    assert(c.debug_enabled == "true" or c.DebugEnabled == true, "debug SMS provider is disabled")
    if r.capability == "config.validate" then return json.encode({valid = true}) end
    assert(r.capability == "sms.send", "unsupported capability")
    S.parameters(p)
    -- Deliberately no delivery and no OTP/phone logging. The app also gates this
    -- first-party plugin with its development-only debug configuration.
    return json.encode({ok = true, simulated = true})
end
