local U = require("lib.util")
local function validate(c)
    U.required(c.pid); U.required(c.key); U.required(c.api_url)
    assert(string.sub(c.api_url, 1, 8) == "https://" and not string.find(c.api_url, "?", 1, true) and not string.find(c.api_url, "#", 1, true), "EasyPay requires a clean HTTPS gateway base URL")
    assert(c.api_mode == "mapi" or c.api_mode == "submit", "invalid EasyPay mode")
end
local function endpoint(c, filename)
    local base = c.api_url
    while string.sub(base, -1) == "/" do base = string.sub(base, 1, -2) end
    for _, suffix in ipairs({"/mapi.php", "/submit.php", "/api.php"}) do
        if string.sub(base, -#suffix) == suffix then base = string.sub(base, 1, #base - #suffix); break end
    end
    return base .. "/" .. filename
end
local function sign(c, params)
    return U.value("crypto.digest", {algorithm = "md5", data = U.canonical(params, {sign = true, sign_type = true}) .. c.key, encoding = "hex"})
end
local function same_signature(a, b)
    if type(a) ~= "string" or #a ~= #b then return false end
    a = string.lower(a); local diff = 0
    for i = 1, #a do diff = diff + math.abs(string.byte(a, i) - string.byte(b, i)) end
    return diff == 0
end
local function product_type(product)
    assert(product == "alipay" or product == "wechat", "unsupported EasyPay product")
    return product == "wechat" and "wxpay" or "alipay"
end
local function callback_type(raw)
    if raw == "wxpay" or raw == "wechat" or raw == "weixin" then return "wechat" end
    if raw == "alipay" then return "alipay" end
    return nil
end
function handle(request)
    if request.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then validate(c); return json.encode({valid = true}) end
    if request.capability == "payment.create" then
        validate(c)
        local form = {pid = c.pid, type = product_type(p.product), out_trade_no = U.required(p.orderNo),
            notify_url = U.required(p.callbackUrl), return_url = c.return_url or "", name = U.required(p.description),
            money = U.decimal(p.amountCents), param = p.attach or "", sign_type = "MD5"}
        if c.api_mode == "mapi" then form.clientip = U.required(p.clientIp); form.device = "pc" end
        form.sign = sign(c, form)
        if c.api_mode == "submit" then
            return U.created(request, {type = "redirect", redirect = {url = endpoint(c, "submit.php") .. "?" .. U.form(form)}})
        end
        local r = U.http({method = "POST", url = endpoint(c, "mapi.php"), body = U.form(form),
            headers = {["Content-Type"] = "application/x-www-form-urlencoded", Accept = "application/json"}})
        local response = U.decode(r.body)
        assert(response.code == "1", "EasyPay create rejected or outcome unknown")
        local result, count = nil, 0
        for _, key in ipairs({"payurl", "qrcode", "urlscheme", "url"}) do
            if response[key] and response[key] ~= "" then count = count + 1; result = {type = "qr", qr = {content = response[key]}} end
        end
        assert(count == 1, "ambiguous or missing EasyPay launch")
        if response.payurl or response.url then result = {type = "redirect", redirect = {url = response.payurl or response.url}} end
        return U.created(request, result)
    elseif request.capability == "payment.query" then
        validate(c)
        local response = U.decode(U.http({method = "GET", url = endpoint(c, "api.php") .. "?" .. U.form({act = "order", pid = c.pid, key = c.key,
            out_trade_no = U.required(p.orderNo)}), headers = {Accept = "application/json"}, body = ""}).body)
        if response.code ~= "1" then return json.encode({orderNo = p.orderNo, status = "unknown", verified = false}) end
        assert(response.out_trade_no == p.orderNo and tostring(response.pid) == c.pid, "EasyPay query merchant/order mismatch")
        local status = response.status == "1" and "paid" or (response.status == "0" and "pending" or "unknown")
        if response.type then assert(callback_type(response.type) == p.product, "EasyPay query product mismatch") end
        return json.encode({orderNo = response.out_trade_no, paymentNo = response.trade_no, status = status, verified = status ~= "unknown",
            amountCents = U.equal_amount(U.from_decimal(response.money), p.amountCents), paidAt = U.time(response.endtime)})
    elseif request.capability == "payment.callback" then
        local form = U.callback_form(p)
        U.required(form.out_trade_no)
        if p.phase == "identify" then return json.encode({orderNo = form.out_trade_no}) end
        assert(p.phase == "verify", "invalid callback phase"); validate(c)
        assert(form.pid == c.pid and form.trade_status == "TRADE_SUCCESS" and (form.sign_type == nil or form.sign_type == "MD5"), "invalid EasyPay callback identity/status")
        assert(same_signature(form.sign, sign(c, form)), "invalid EasyPay callback signature")
        local product = callback_type(form.type)
        assert(product ~= nil, "missing or unsupported EasyPay callback product")
        return json.encode({orderNo = form.out_trade_no, paymentNo = U.required(form.trade_no), product = product,
            amountCents = U.from_decimal(form.money), status = "paid", verified = true, ack = U.ack(),
            paidAt = form.gmt_payment and U.time(form.gmt_payment) or U.now().rfc3339})
    end
    error("unsupported capability")
end
