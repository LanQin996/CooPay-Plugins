local U = require("lib.util")
local M = {}
function M.validate(c)
    for _, k in ipairs({"appid", "private_key", "alipay_public_key"}) do U.required(c[k], k .. " required") end
end
function M.check(c)
    M.validate(c)
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key, data = "CooPay complaint key validation", encoding = "base64"})
    U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key, data = "CooPay complaint key validation", signature = signature, encoding = "base64"})
end
function M.origin(c)
    if not c.gateway_url or c.gateway_url == "" then return "https://openapi.alipay.com" end
    local raw = U.required(c.gateway_url)
    assert(string.sub(raw, 1, 8) == "https://" and not string.find(raw, "?", 1, true) and not string.find(raw, "#", 1, true), "invalid Alipay complaint gateway")
    local stop = string.find(raw, "/", 9, true) or (#raw + 1)
    return string.sub(raw, 1, stop - 1)
end
function M.headers(c, method, target, body)
    M.validate(c); body = body or ""
    local random = U.value("random.bytes", {size = 16, encoding = "hex"})
    local nonce = string.sub(random, 1, 8) .. "-" .. string.sub(random, 9, 12) .. "-" .. string.sub(random, 13, 16) .. "-" .. string.sub(random, 17, 20) .. "-" .. string.sub(random, 21)
    local timestamp = string.format("%.0f", U.now().unix * 1000)
    local auth = "app_id=" .. c.appid .. ",nonce=" .. nonce .. ",timestamp=" .. timestamp
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key,
        data = auth .. "\n" .. method .. "\n" .. target .. "\n" .. body .. "\n", encoding = "base64"})
    return {Authorization = "ALIPAY-SHA256withRSA " .. auth .. ",sign=" .. signature, Accept = "application/json", ["Content-Type"] = "application/json"}
end
function M.verify(c, response)
    local ts, n, sig = U.header(response.headers, "alipay-timestamp"), U.header(response.headers, "alipay-nonce"), U.header(response.headers, "alipay-signature")
    U.required(ts); U.required(n); U.required(sig)
    assert(tonumber(ts) and math.abs(U.now().unix * 1000 - tonumber(ts)) <= 300000, "expired Alipay complaint signature")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key,
        data = ts .. "\n" .. n .. "\n" .. response.body .. "\n", signature = sig, encoding = "base64"}) == true, "invalid Alipay complaint signature")
end
function M.request(c, method, target, body)
    body = body or ""
    local response = U.http({method = method, url = M.origin(c) .. target, body = body, headers = M.headers(c, method, target, body)})
    M.verify(c, response); return response.body
end
function M.upload(c, p)
    local id = U.required(p.blobId)
    local info = U.call("blob.info", {id = id})
    assert(type(info.size) == "number" and info.size > 0 and info.size <= 2097152, "Alipay complaint image exceeds 2 MiB")
    local image_types = {["image/png"] = "png", ["image/jpeg"] = "jpg"}
    assert(image_types[info.contentType], "Alipay complaint images require JPEG or PNG")
    assert(not p.contentType or p.contentType == "" or p.contentType == info.contentType, "image content type mismatch")
    local data = json.encode({image_type = image_types[info.contentType]})
    local target = "/v3/alipay/merchant/image/upload"
    local headers = M.headers(c, "POST", target, data); headers["Content-Type"] = nil
    local response = U.call("https.multipart", {method = "POST", url = M.origin(c) .. target, headers = headers,
        fields = {data = data}, fieldContentTypes = {data = "application/json"},
        parts = {{name = "image_content", filename = "complaint-image." .. image_types[info.contentType], contentType = info.contentType, blobId = id}}})
    assert(type(response.status) == "number" and response.status >= 200 and response.status < 300, "Alipay image upload outcome unknown")
    M.verify(c, response)
    return {mediaId = U.required(U.decode(response.body).image_id), mediaType = info.contentType}
end
function M.media(detail)
    local list, urls, seen = {}, {}, {}
    local function add(items)
        if items == nil or items == json.null then return end
        assert(type(items) == "table" and #items <= 64, "invalid Alipay complaint media list")
        for _, item in ipairs(items) do
            local url = type(item) == "string" and item or (type(item) == "table" and (item.url or item.image_url))
            if type(url) == "string" and string.sub(url, 1, 8) == "https://" then
                local stop = string.find(url, "/", 9, true) or (#url + 1)
                local origin = string.sub(url, 1, stop - 1)
                if origin == "https://mdn.alipayobjects.com" or origin == "https://gw.alipayobjects.com" then
                    assert(#url <= 8192 and not string.find(url, "#", 1, true), "invalid Alipay complaint media URL")
                    local id = U.value("crypto.digest", {algorithm = "sha256", data = url, encoding = "hex"})
                    if not seen[id] then
                        assert(#list < 64, "too many Alipay complaint images")
                        seen[id] = true; list[#list + 1] = {mediaId = id, mediaType = ""}; urls[id] = url
                    end
                end
            end
        end
    end
    add(detail.images)
    if type(detail.reply_detail_infos) == "table" then
        assert(#detail.reply_detail_infos <= 64, "too many complaint replies")
        for _, reply in ipairs(detail.reply_detail_infos) do if type(reply) == "table" then add(reply.reply_images) end end
    end
    return json.array(list), urls
end
return M
