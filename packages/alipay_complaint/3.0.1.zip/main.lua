local U, A = require("lib.util"), require("lib.alipay")
local base = "/v3/alipay/merchant/tradecomplain/"
local function identifier(value)
    U.required(value); assert(#value <= 64, "Alipay complaint id too long")
    for _, bad in ipairs({"/", "\\", "\r", "\n", "\0"}) do assert(not string.find(value, bad, 1, true), "invalid Alipay complaint id") end
    return value
end
local function text(value, limit, required)
    if value == nil or value == "" then assert(not required, "Alipay complaint text required"); return nil end
    U.required(value); local count = 0
    for i = 1, #value do local byte = string.byte(value, i); assert(byte ~= 0, "invalid text"); if byte < 128 or byte >= 192 then count = count + 1 end end
    assert(count <= limit, "Alipay complaint text too long"); return value
end
local function detail(c, event_id)
    local id = identifier(event_id)
    local raw = A.request(c, "GET", base .. U.url(id))
    local result = U.decode(raw)
    assert(result.complain_event_id == id, "Alipay complaint identity mismatch")
    assert(result.target_id == nil or result.target_id == c.appid, "Alipay complaint APPID mismatch")
    return raw, result
end
function handle(request)
    if request.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then A.check(c); return json.encode({valid = true}) end
    if request.capability == "complaint.query" then
        if p.operation == "get" then
            local raw, result = detail(c, p.eventId)
            local list = A.media(result)
            local last = #raw
            while last > 0 and string.sub(raw, last, last) ~= "}" do last = last - 1 end
            assert(last > 0 and result.mediaList == nil, "ambiguous Alipay complaint result")
            return string.sub(raw, 1, last - 1) .. ',"mediaList":' .. json.encode(list) .. '}'
        elseif p.operation == "media_download" then
            local _, result = detail(c, p.eventId)
            local _, urls = A.media(result)
            local url = urls[U.required(p.mediaId)]
            assert(url, "media does not belong to the verified complaint")
            local response = U.http({method = "GET", url = url, headers = {Accept = "image/png,image/jpeg"}, body = "", responseBlob = true})
            local info = U.call("blob.info", {id = U.required(response.blobId)})
            assert(info.size > 0 and info.size <= 10485760 and (info.contentType == "image/jpeg" or info.contentType == "image/png"), "invalid Alipay complaint image")
            return json.encode({mediaId = p.mediaId, mediaType = info.contentType, blobId = response.blobId, downloaded = true})
        elseif p.operation == "list" then
            assert(type(p.pageNum) == "number" and p.pageNum >= 1 and p.pageNum == math.floor(p.pageNum), "invalid complaint page number")
            assert(type(p.pageSize) == "number" and p.pageSize >= 1 and p.pageSize <= 20 and p.pageSize == math.floor(p.pageSize), "invalid complaint page size")
            local body = {target_infos = {{target_type = "APPID", target_id = c.appid}}, begin_time = text(p.beginTime, 64, false),
                end_time = text(p.endTime, 64, false), page_num = p.pageNum, page_size = p.pageSize, status = text(p.status, 64, false)}
            local raw = A.request(c, "POST", base .. "batchquery", json.encode(body))
            local result, seen = U.decode(raw), {}
            assert(type(result.trade_complain_infos) == "table" and #result.trade_complain_infos <= p.pageSize and tonumber(result.total_num) and tonumber(result.total_num) >= 0, "invalid complaint list")
            -- Live Alipay returns its default page 0/size 10 for an empty
            -- result, even when page 1/size 20 was requested. Adapt only this
            -- signed zero-result sentinel; populated pages keep strict checks
            -- and their raw JSON bytes, including exact monetary values.
            if #result.trade_complain_infos == 0 and tonumber(result.total_num) == 0 and
               tonumber(result.total_page_num) == 0 and tonumber(result.page_num) == 0 and tonumber(result.page_size) == 10 then
                return json.encode({trade_complain_infos = json.array({}), total_num = 0, total_page_num = 0,
                    page_num = p.pageNum, page_size = p.pageSize})
            end
            assert(result.page_num == nil or tonumber(result.page_num) == p.pageNum, "complaint page number mismatch")
            assert(result.page_size == nil or tonumber(result.page_size) == p.pageSize, "complaint page size mismatch")
            for _, item in ipairs(result.trade_complain_infos) do
                local id = identifier(item.complain_event_id)
                assert(not seen[id], "duplicate Alipay complaint"); seen[id] = true
                assert(item.target_id == nil or item.target_id == c.appid, "Alipay complaint list APPID mismatch")
            end
            return raw
        end
        error("unsupported Alipay complaint query")
    elseif request.capability == "complaint.handle" then
        if p.operation == "media_upload" then detail(c, p.eventId); return json.encode(A.upload(c, p)) end
        local operation, fields = p.operation, p.fields
        local allowed = {
            feedback = {complain_event_id = true, feedback_code = true, feedback_content = true, feedback_images = true, operator = true},
            reply = {complain_event_id = true, reply_content = true, reply_images = true},
            supplement = {complain_event_id = true, supplement_content = true, supplement_images = true}
        }
        assert(allowed[operation] and type(fields) == "table", "unsupported Alipay complaint operation")
        identifier(fields.complain_event_id)
        for k, v in pairs(fields) do assert(allowed[operation][k] and type(v) == "string", "unsupported Alipay complaint field") end
        local content = {feedback = "feedback_content", reply = "reply_content", supplement = "supplement_content"}
        text(fields[content[operation]], 200, true)
        if operation == "feedback" then
            local codes = {["02"] = true, ["03"] = true, ["04"] = true, ["05"] = true, ["06"] = true, ["194"] = true}
            assert(codes[fields.feedback_code], "invalid Alipay feedback code"); text(fields.operator, 6, false)
        end
        A.request(c, "POST", base .. operation, json.encode(fields))
        return json.encode({ok = true})
    end
    error("unsupported capability")
end
