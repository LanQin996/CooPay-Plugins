local W = require("lib.wechat")
local payment_states = {SUCCESS = "paid", CLOSED = "closed", REVOKED = "closed", PAYERROR = "closed", NOTPAY = "pending", USERPAYING = "pending", ACCEPT = "pending"}
local refund_states = {SUCCESS = "success", PROCESSING = "pending", CHANGE = "pending", REFUNDCLOSE = "failed"}
local function currency(r)
    assert(r.fee_type == nil or r.fee_type == "CNY", "unsupported WeChat currency")
end
local function payment(r, p, callback)
    currency(r)
    assert(r.out_trade_no == p.orderNo and (not p.product or p.product == "native"), "WeChat order/product mismatch")
    if r.trade_type then assert(r.trade_type == "NATIVE", "WeChat trade type mismatch") end
    local status = callback and "paid" or (payment_states[r.trade_state] or "unknown")
    -- A signed query may omit the original amount for an unpaid order. Keep
    -- the binding as an unknown observation; never manufacture paid evidence.
    if not r.total_fee then
        assert(status ~= "paid", "missing paid amount")
        return {orderNo = p.orderNo, product = "native", status = "unknown", verified = false, amountCents = W.cents(p.amountCents)}
    end
    local result = {orderNo = r.out_trade_no, product = "native", paymentNo = r.transaction_id or "", status = status,
        verified = status ~= "unknown", amountCents = W.equal_amount(r.total_fee, p.amountCents)}
    if status == "paid" then
        assert(r.trade_type == "NATIVE", "missing paid trade type")
        W.required(result.paymentNo); result.paidAt = W.time(r.time_end, true)
    end
    return result
end
local function refund_result(r, p, status, provider_id, amount, time)
    currency(r)
    assert(r.out_trade_no == p.orderNo, "WeChat refund order mismatch")
    local result = {orderNo = r.out_trade_no, refundNo = p.refundNo, providerRefundNo = W.required(provider_id),
        amountCents = W.equal_amount(amount, p.amountCents), totalCents = W.equal_amount(r.total_fee, p.totalCents),
        status = status, verified = status ~= "unknown"}
    if status == "success" then result.successAt = W.time(time, false) end
    return result
end
local function refund_query(c, p)
    local r = W.request(c, "/pay/refundquery", {out_refund_no = W.refund_no(p.refundNo)})
    if r.result_code == "FAIL" and r.err_code == "REFUNDNOTEXIST" then
        return {orderNo = W.order(p.orderNo), refundNo = p.refundNo, amountCents = W.cents(p.amountCents),
            totalCents = W.cents(p.totalCents), status = "not_found", verified = true}
    end
    W.success(r)
    assert(r.refund_count == "1" and r.out_refund_no_0 == p.refundNo, "ambiguous WeChat refund query")
    return refund_result(r, p, refund_states[r.refund_status_0] or "unknown", r.refund_id_0, r.refund_fee_0, r.refund_success_time_0)
end
function handle(request)
    if request.capability == "health" then
        -- Older API builds also speak plugin protocol v2 but do not yet have
        -- the XML primitives. Reject activation before accepting orders.
        assert(W.xml("<xml><ready>yes</ready></xml>").ready == "yes", "host XML support required")
        return json.encode({ok = true})
    end
    local c, p = W.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then W.check(c); return json.encode({valid = true}) end
    if request.capability == "refund.validate" then
        W.order(p.orderNo); W.equal_amount(p.amountCents, p.totalCents)
        assert(#(p.reason or "") <= 80, "refund reason exceeds WeChat limit")
        return json.encode({valid = W.refund_ready(c), message = "API退款需先在渠道配置中填写商户API证书和证书私钥"})
    end
    if request.capability == "payment.create" then
        assert(p.product == "native", "unsupported WeChat V2 product")
        W.order(p.orderNo); W.required(p.description); W.required(p.clientIp)
        assert(#p.description <= 127 and #(p.attach or "") <= 127 and #p.clientIp <= 64, "WeChat request field too long")
        local r = W.request(c, "/pay/unifiedorder", {out_trade_no = p.orderNo, product_id = p.orderNo, trade_type = "NATIVE",
            body = p.description, attach = p.attach or "", total_fee = W.cents(p.amountCents), fee_type = "CNY",
            spbill_create_ip = p.clientIp, notify_url = W.callback_url(p.callbackUrl, "orderNo", p.orderNo)})
        W.success(r); assert(r.trade_type == "NATIVE", "WeChat create product mismatch"); W.required(r.prepay_id)
        local binding = request.binding or {pluginId = request.pluginId, pluginVersion = request.version, orderNo = p.orderNo,
            product = p.product, amountCents = p.amountCents, currency = "CNY"}
        return json.encode({binding = binding, product = p.product, launch = {type = "qr", qr = {content = W.required(r.code_url)}}})
    elseif request.capability == "payment.query" then
        local r = W.request(c, "/pay/orderquery", {out_trade_no = W.order(p.orderNo)})
        if r.result_code ~= "SUCCESS" then
            return json.encode({orderNo = p.orderNo, amountCents = W.cents(p.amountCents), status = "unknown", verified = false})
        end
        return json.encode(payment(r, p, false))
    elseif request.capability == "refund.create" then
        W.order(p.orderNo); W.refund_no(p.refundNo)
        W.equal_amount(p.amountCents, p.totalCents)
        assert(#(p.reason or "") <= 80, "refund reason exceeds WeChat limit")
        local fields = {out_trade_no = p.orderNo, out_refund_no = p.refundNo, total_fee = W.cents(p.totalCents),
            refund_fee = W.cents(p.amountCents), refund_fee_type = "CNY", refund_desc = p.reason or ""}
        if p.callbackUrl and p.callbackUrl ~= "" then fields.notify_url = W.callback_url(p.callbackUrl, "refundNo", p.refundNo) end
        local r = W.request(c, "/secapi/pay/refund", fields, true)
        W.success(r); assert(r.out_refund_no == p.refundNo, "WeChat refund identity mismatch")
        -- SUCCESS means accepted, not refunded. Only query/notification settles.
        return json.encode(refund_result(r, p, "pending", r.refund_id, r.refund_fee))
    elseif request.capability == "refund.query" then
        return json.encode(refund_query(c, p))
    elseif request.capability == "payment.callback" then
        local r = W.callback_body(p); W.order(r.out_trade_no)
        if p.phase == "identify" then return json.encode({orderNo = r.out_trade_no}) end
        assert(p.phase == "verify" and r.return_code == "SUCCESS" and r.result_code == "SUCCESS", "invalid payment notification")
        W.validate(c); W.verify(c, r, r.sign_type or "MD5")
        assert(p.orderNo == nil or p.orderNo == r.out_trade_no, "payment callback binding mismatch")
        p.orderNo = r.out_trade_no
        local result = payment(r, p, true); result.ack = W.ack(); return json.encode(result)
    elseif request.capability == "refund.callback" then
        local hint = W.refund_hint(p.path)
        if p.phase == "identify" then return json.encode({refundNo = hint}) end
        assert(p.phase == "verify", "invalid callback phase"); W.validate(c)
        local outer = W.callback_body(p); assert(outer.return_code == "SUCCESS", "refund notification failed")
        W.identity(c, outer)
        local key = W.value("crypto.digest", {algorithm = "md5", data = c.api_v2_key, encoding = "hex"})
        local plain = W.value("crypto.aes_ecb_decrypt", {key = key, ciphertext = W.required(outer.req_info)})
        local r = W.xml(plain, "root")
        assert(r.out_refund_no == hint and p.refundNo == hint and r.out_trade_no == p.orderNo, "refund callback binding mismatch")
        assert(r.refund_status == "SUCCESS", "refund notification is not successful")
        W.equal_amount(r.refund_fee, p.amountCents); W.equal_amount(r.total_fee, p.totalCents)
        -- ECB is not authenticated encryption: independently query the exact
        -- refund with a verified signature before permitting any ledger update.
        local result = refund_query(c, p)
        assert(result.status == "success" and result.providerRefundNo == W.required(r.refund_id), "refund notification not confirmed by query")
        result.ack = W.ack(); return json.encode(result)
    end
    error("unsupported capability")
end
