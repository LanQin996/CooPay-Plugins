local M = {}
function M.call(op, value) return json.decode(host.call(op, json.encode(value or {}))) end
function M.value(op, value)
    local r = M.call(op, value); assert(r.value ~= nil, "missing host result"); return r.value
end
function M.required(value, label)
    assert(type(value) == "string" and #value > 0 and #value <= 32768, label or "required string")
    return value
end
function M.config(request)
    local c = {}; for k, v in pairs(request.credentials or {}) do c[k] = v end; return c
end
function M.validate(c)
    M.required(c.merchant_id); M.required(c.appid); M.required(c.api_v2_key)
    assert(#c.merchant_id <= 32 and #c.appid <= 32 and #c.api_v2_key == 32, "invalid WeChat V2 credentials")
end
function M.check(c)
    M.validate(c)
end
function M.cents(value)
    assert(type(value) == "string" and #value > 0 and #value <= 10 and string.sub(value, 1, 1) ~= "0" and
        (#value < 10 or value <= "2147483647"), "WeChat V2 requires positive int32 cents string")
    for i = 1, #value do local b = string.byte(value, i); assert(b >= 48 and b <= 57, "invalid cents") end
    return value
end
function M.equal_amount(value, expected)
    value = M.cents(value); if expected then assert(value == M.cents(expected), "WeChat amount mismatch") end; return value
end
local function identifier(value, max)
    M.required(value); assert(#value <= max, "WeChat identifier too long")
    for i = 1, #value do
        local b = string.byte(value, i)
        assert((b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b == 95 or b == 45 or b == 124 or b == 42, "invalid WeChat identifier")
    end
    return value
end
function M.order(value)
    value = identifier(value, 32); assert(#value >= 6, "WeChat order number too short"); return value
end
function M.keys(fields)
    local keys = {}; for k in pairs(fields) do keys[#keys + 1] = k end; table.sort(keys); return keys
end
function M.signature(c, fields, algorithm)
    local parts = {}
    for _, k in ipairs(M.keys(fields)) do
        if k ~= "sign" and fields[k] ~= "" then
            assert(type(fields[k]) == "string", "WeChat XML values must be strings")
            parts[#parts + 1] = k .. "=" .. fields[k]
        end
    end
    local data = table.concat(parts, "&") .. "&key=" .. c.api_v2_key
    if algorithm == "MD5" then return string.upper(M.value("crypto.digest", {algorithm = "md5", data = data, encoding = "hex"})) end
    assert(algorithm == "HMAC-SHA256", "unsupported signature algorithm")
    return string.upper(M.value("crypto.hmac", {algorithm = "sha256", data = data, key = c.api_v2_key, encoding = "hex"}))
end
function M.same(a, b)
    if type(a) ~= "string" or #a ~= #b then return false end
    local diff = 0; for i = 1, #a do diff = diff + math.abs(string.byte(a, i) - string.byte(b, i)) end; return diff == 0
end
function M.identity(c, r)
    assert(r.appid == c.appid and r.mch_id == c.merchant_id, "WeChat merchant/app identity mismatch")
    assert(r.sub_mch_id == nil and r.sub_appid == nil, "service provider mode is not supported")
end
function M.verify(c, fields, algorithm)
    M.identity(c, fields)
    assert(fields.sign_type == nil or fields.sign_type == algorithm, "WeChat signature algorithm mismatch")
    assert(M.same(fields.sign, M.signature(c, fields, algorithm)), "invalid WeChat V2 signature")
end
function M.xml(raw, root) return M.value("xml.decode", {data = raw, root = root or "xml"}) end
function M.request(c, path, fields)
    M.validate(c)
    fields.appid, fields.mch_id, fields.sign_type = c.appid, c.merchant_id, "MD5"
    fields.nonce_str = M.value("random.bytes", {size = 16, encoding = "hex"})
    fields.sign = M.signature(c, fields, "MD5")
    local request = {method = "POST", url = "https://api.mch.weixin.qq.com" .. path,
        headers = {["Content-Type"] = "application/xml; charset=utf-8", Accept = "application/xml"},
        body = M.value("xml.encode", {fields = fields})}
    local response = M.call("https.request", request)
    assert(response.status == 200, "WeChat remote outcome unknown: HTTP failure")
    local r = M.xml(response.body)
    assert(r.return_code == "SUCCESS", "WeChat communication failed; outcome not confirmed")
    M.verify(c, r, "MD5")
    assert(r.result_code == "SUCCESS" or r.result_code == "FAIL", "missing WeChat business result")
    return r
end
function M.success(r) assert(r.result_code == "SUCCESS", "WeChat business result not confirmed") end
function M.time(raw, compact)
    M.required(raw)
    return M.value("time.parse", {value = raw, layout = compact and "20060102150405" or "2006-01-02 15:04:05", offsetSeconds = 28800})
end
function M.callback_url(raw, key, id)
    M.required(raw); assert(string.sub(raw, 1, 8) == "https://" and not string.find(raw, "#", 1, true), "callback must use HTTPS")
    local query = string.find(raw, "?", 1, true)
    if query then
        local expected = key .. "=" .. M.value("encoding.url_encode", {data = id})
        assert(string.sub(raw, query + 1) == expected, "unsupported callback query")
        raw = string.sub(raw, 1, query - 1)
    end
    assert(#raw <= 256, "callback URL too long"); return raw
end
function M.callback_body(p)
    assert(p.method == "POST", "WeChat notification requires POST")
    return M.xml(M.value("encoding.base64_decode", {data = M.required(p.bodyBase64)}))
end
function M.ack()
    return {statusCode = 200, contentType = "application/xml; charset=utf-8",
        body = "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>"}
end
return M
