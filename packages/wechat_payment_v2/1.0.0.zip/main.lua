local W = require("lib.wechat")
local payment_states = {SUCCESS = "paid", CLOSED = "closed", REVOKED = "closed", PAYERROR = "closed", NOTPAY = "pending", USERPAYING = "pending", ACCEPT = "pending"}
local function currency(r)
    assert(r.fee_type == nil or r.fee_type == "CNY", "unsupported WeChat currency")
end
local function payment(r, p, callback)
    currency(r)
    assert(r.out_trade_no == p.orderNo and (not p.product or p.product == "native"), "WeChat order/product mismatch")
    if r.trade_type then assert(r.trade_type == "NATIVE", "WeChat trade type mismatch") end
    local status = callback and "paid" or (payment_states[r.trade_state] or "unknown")
    -- A signed query may omit the original amount for an unpaid order. Keep
    -- the binding as an unknown observation; never manufacture paid evidence.
    if not r.total_fee then
        assert(status ~= "paid", "missing paid amount")
        return {orderNo = p.orderNo, product = "native", status = "unknown", verified = false, amountCents = W.cents(p.amountCents)}
    end
    local result = {orderNo = r.out_trade_no, product = "native", paymentNo = r.transaction_id or "", status = status,
        verified = status ~= "unknown", amountCents = W.equal_amount(r.total_fee, p.amountCents)}
    if status == "paid" then
        assert(r.trade_type == "NATIVE", "missing paid trade type")
        W.required(result.paymentNo); result.paidAt = W.time(r.time_end, true)
    end
    return result
end
function handle(request)
    if request.capability == "health" then
        -- Older API builds also speak plugin protocol v2 but do not yet have
        -- the XML primitives. Reject activation before accepting orders.
        assert(W.xml("<xml><ready>yes</ready></xml>").ready == "yes", "host XML support required")
        return json.encode({ok = true})
    end
    local c, p = W.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then W.check(c); return json.encode({valid = true}) end
    if request.capability == "payment.create" then
        assert(p.product == "native", "unsupported WeChat V2 product")
        W.order(p.orderNo); W.required(p.description); W.required(p.clientIp)
        assert(#p.description <= 127 and #(p.attach or "") <= 127 and #p.clientIp <= 64, "WeChat request field too long")
        local r = W.request(c, "/pay/unifiedorder", {out_trade_no = p.orderNo, product_id = p.orderNo, trade_type = "NATIVE",
            body = p.description, attach = p.attach or "", total_fee = W.cents(p.amountCents), fee_type = "CNY",
            spbill_create_ip = p.clientIp, notify_url = W.callback_url(p.callbackUrl, "orderNo", p.orderNo)})
        W.success(r); assert(r.trade_type == "NATIVE", "WeChat create product mismatch"); W.required(r.prepay_id)
        local binding = request.binding or {pluginId = request.pluginId, pluginVersion = request.version, orderNo = p.orderNo,
            product = p.product, amountCents = p.amountCents, currency = "CNY"}
        return json.encode({binding = binding, product = p.product, launch = {type = "qr", qr = {content = W.required(r.code_url)}}})
    elseif request.capability == "payment.query" then
        local r = W.request(c, "/pay/orderquery", {out_trade_no = W.order(p.orderNo)})
        if r.result_code ~= "SUCCESS" then
            return json.encode({orderNo = p.orderNo, amountCents = W.cents(p.amountCents), status = "unknown", verified = false})
        end
        return json.encode(payment(r, p, false))
    elseif request.capability == "payment.callback" then
        local r = W.callback_body(p); W.order(r.out_trade_no)
        if p.phase == "identify" then return json.encode({orderNo = r.out_trade_no}) end
        assert(p.phase == "verify" and r.return_code == "SUCCESS" and r.result_code == "SUCCESS", "invalid payment notification")
        W.validate(c); W.verify(c, r, r.sign_type or "MD5")
        assert(p.orderNo == nil or p.orderNo == r.out_trade_no, "payment callback binding mismatch")
        p.orderNo = r.out_trade_no
        local result = payment(r, p, true); result.ack = W.ack(); return json.encode(result)

    end
    error("unsupported capability")
end
