local U = require("lib.util")
local M = {}
function M.validate(c)
    for _, k in ipairs({"appid", "private_key", "alipay_public_key"}) do U.required(c[k], k .. " required") end
end
function M.gateway(c)
    return c.gateway_url and c.gateway_url ~= "" and c.gateway_url or "https://openapi.alipay.com/gateway.do"
end
function M.check(c)
    M.validate(c)
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key, data = "CooPay plugin key validation", encoding = "base64"})
    U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key, data = "CooPay plugin key validation", signature = signature, encoding = "base64"})
end
function M.parameters(c, method, biz, notify)
    M.validate(c)
    local p = {app_id = c.appid, method = method, format = "JSON", charset = "utf-8", sign_type = "RSA2",
        timestamp = U.value("time.format", {unix = U.now().unix, layout = "2006-01-02 15:04:05", offsetSeconds = 28800}),
        version = "1.0", biz_content = json.encode(biz)}
    if notify then p.notify_url = notify end
    p.sign = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key,
        data = U.canonical(p, {sign = true}), encoding = "base64"})
    return p
end
function M.request(c, method, biz, notify)
    local p = M.parameters(c, method, biz, notify)
    local response = U.http({method = "POST", url = M.gateway(c), body = U.form(p),
        headers = {["Content-Type"] = "application/x-www-form-urlencoded;charset=utf-8", Accept = "application/json"}})
    local envelope = U.decode(response.body)
    local response_name = ""
    for i = 1, #method do local ch = string.sub(method, i, i); response_name = response_name .. (ch == "." and "_" or ch) end
    response_name = response_name .. "_response"
    local raw = U.required(U.raw_field(response.body, response_name), "missing signed Alipay response")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key,
        data = raw, signature = U.required(envelope.sign), encoding = "base64"}) == true, "invalid Alipay response signature")
    local result = U.decode(raw)
    assert(result.code == "10000", "Alipay operation rejected or outcome unknown")
    return result
end
function M.verify_callback(c, p)
    M.validate(c)
    assert(p.sign_type == "RSA2", "unsupported Alipay signature type")
    assert(p.app_id == c.appid and (not c.pid or c.pid == "" or p.seller_id == c.pid), "Alipay merchant identity mismatch")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key,
        data = U.canonical(p, {sign = true, sign_type = true}), signature = U.required(p.sign), encoding = "base64"}) == true, "invalid Alipay callback signature")
end
return M
