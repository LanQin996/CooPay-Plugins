local U = require("lib.util")
local A = require("lib.alipay")
local scenes = {FACE = true, SMART_FACE = true, CERT_PHOTO = true, CERT_PHOTO_FACE = true}
local function config(c)
    A.validate(c)
    assert(scenes[c.biz_code], "unsupported identity verification scenario")
    -- First release supports the public-key RSA2 gateway, not certificate/ISV mode.
    assert(not c.gateway_url and not c.app_auth_token, "unsupported gateway or delegated mode")
end
local function token(value)
    U.required(value); assert(#value <= 512, "invalid certification id")
    for i = 1, #value do
        local b = string.byte(value, i)
        assert((b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122), "invalid certification id")
    end
    return value
end
function handle(r)
    if r.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(r), json.decode(r.payload)
    config(c)
    if r.capability == "config.validate" then A.check(c); return json.encode({valid = true}) end
    if r.capability == "realname.start" then
        U.required(p.name); U.required(p.idCard); U.required(p.callbackUrl)
        assert(#p.name <= 128 and #p.idCard == 18 and #p.callbackUrl <= 2048, "invalid identity input")
        assert(string.sub(p.callbackUrl, 1, 8) == "https://", "identity callback requires public HTTPS")
        -- Alipay returns to the merchant URL but does not echo Tencent's AuthToken.
        -- Keep an opaque browser correlation separate from the provider query id.
        local correlation = "ctx_" .. U.value("random.bytes", {size = 24, encoding = "hex"})
        local callback = U.add_query(p.callbackUrl, "AuthToken", correlation)
        local outer = U.value("random.bytes", {size = 16, encoding = "hex"})
        local result = A.request(c, "alipay.user.certify.open.initialize", {
            outer_order_no = outer, biz_code = c.biz_code,
            identity_param = {identity_type = "CERT_INFO", cert_type = "IDENTITY_CARD", cert_name = p.name, cert_no = p.idCard},
            merchant_config = {return_url = callback, face_reserve_strategy = "never"}
        })
        local id = token(result.certify_id)
        local params = A.parameters(c, "alipay.user.certify.open.certify", {certify_id = id})
        return json.encode({AuthToken = id, CallbackToken = correlation,
            RedirectURL = "https://openapi.alipay.com/gateway.do?" .. U.form(params)})
    elseif r.capability == "realname.query" then
        local result = A.request(c, "alipay.user.certify.open.query", {certify_id = token(p.authToken)})
        assert(result.passed == "T" or result.passed == "F", "unrecognized certification result")
        return json.encode({Status = result.passed == "T" and "PASSED" or "FAILED", ResultType = result.passed,
            Message = result.passed == "T" and "identity verification passed" or "identity verification did not pass"})
    end
    error("unsupported capability")
end
