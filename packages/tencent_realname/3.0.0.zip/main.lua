local U = require("lib.util")
local function credentials(c)
    return U.required(c.secret_id or c.SecretID), U.required(c.secret_key or c.SecretKey), U.required(c.region or c.Region)
end
local function request(c, action, fields)
    local id, key, region = credentials(c)
    local now, content_type = U.now(), "application/json; charset=utf-8"
    local body = json.encode(fields)
    local function digest(data) return U.value("crypto.digest", {algorithm = "sha256", data = data, encoding = "hex"}) end
    local function hmac(secret, data, hex_key)
        return U.value("crypto.hmac", {algorithm = "sha256", key = secret, keyEncoding = hex_key and "hex" or "raw", data = data, encoding = "hex"})
    end
    local canonical = "POST\n/\n\ncontent-type:" .. content_type .. "\nhost:faceid.tencentcloudapi.com\n\ncontent-type;host\n" .. digest(body)
    local scope = now.date .. "/faceid/tc3_request"
    local to_sign = "TC3-HMAC-SHA256\n" .. tostring(now.unix) .. "\n" .. scope .. "\n" .. digest(canonical)
    local signing = hmac(hmac(hmac("TC3" .. key, now.date, false), "faceid", true), "tc3_request", true)
    local authorization = "TC3-HMAC-SHA256 Credential=" .. id .. "/" .. scope .. ", SignedHeaders=content-type;host, Signature=" .. hmac(signing, to_sign, true)
    local response = U.decode(U.http({method = "POST", url = "https://faceid.tencentcloudapi.com/", body = body,
        headers = {["Content-Type"] = content_type, ["X-TC-Action"] = action, ["X-TC-Version"] = "2018-03-01",
            ["X-TC-Region"] = region, ["X-TC-Timestamp"] = tostring(now.unix), Authorization = authorization}}).body)
    assert(type(response.Response) == "table" and not response.Response.Error, "Tencent FaceID rejected request or outcome unknown")
    return response.Response
end
function handle(r)
    if r.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(r), json.decode(r.payload)
    if r.capability == "config.validate" then credentials(c); return json.encode({valid = true}) end
    if r.capability == "realname.start" then
        local result = request(c, "GetRealNameAuthToken", {Name = U.required(p.name), IDCard = U.required(p.idCard), CallbackURL = U.required(p.callbackUrl)})
        assert(string.sub(U.required(result.RedirectURL), 1, 8) == "https://", "invalid Tencent redirect URL")
        assert(#U.required(result.AuthToken) <= 512, "invalid Tencent authentication token")
        return json.encode({AuthToken = U.required(result.AuthToken), RedirectURL = U.required(result.RedirectURL)})
    elseif r.capability == "realname.query" then
        local result = request(c, "GetRealNameAuthResult", {AuthToken = U.required(p.authToken)})
        local code = U.required(result.ResultType)
        local messages = {["-1"] = "name and identity number do not match", ["-2"] = "identity name does not match the verified account", ["-3"] = "the provider account is not identity verified"}
        return json.encode({Status = code == "0" and "PASSED" or "FAILED", ResultType = code,
            Message = code == "0" and "real-name authentication passed" or messages[code] or "real-name authentication failed"})
    end
    error("unsupported capability")
end
