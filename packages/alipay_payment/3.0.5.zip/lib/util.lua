local M = {}
function M.call(operation, payload)
    return json.decode(host.call(operation, json.encode(payload or {})))
end
function M.value(operation, payload)
    local r = M.call(operation, payload)
    assert(r.value ~= nil, "missing host operation result")
    return r.value
end
function M.required(value, label)
    assert(type(value) == "string" and #value > 0 and #value <= 32768, label or "required string")
    return value
end
function M.config(request)
    local c = {}
    for k, v in pairs(request.config or {}) do c[k] = v end
    for k, v in pairs(request.credentials or {}) do c[k] = v end
    return c
end
function M.encode(value) return json.encode(value) end
-- Quote numeric JSON tokens before decoding. Lua never sees monetary integers
-- as IEEE-754 numbers, even above 2^53. Strings/escapes remain byte-for-byte.
function M.decode(raw)
    json.decode(raw) -- Validate the original JSON grammar before token rewriting.
    local out, i, quoted = {}, 1, false
    while i <= #raw do
        local c = string.sub(raw, i, i)
        if c == '"' then
            quoted = not quoted; out[#out + 1] = c; i = i + 1
        elseif quoted and c == "\\" then
            out[#out + 1] = string.sub(raw, i, i + 1); i = i + 2
        elseif not quoted and (c == "-" or (c >= "0" and c <= "9")) then
            local start = i
            repeat i = i + 1; c = string.sub(raw, i, i)
            until c == "" or not ((c >= "0" and c <= "9") or c == "." or c == "e" or c == "E" or c == "+" or c == "-")
            out[#out + 1] = '"' .. string.sub(raw, start, i - 1) .. '"'
        else out[#out + 1] = c; i = i + 1 end
    end
    return json.decode(table.concat(out))
end
-- Preserve the exact signed bytes of a top-level JSON member (Alipay replies).
function M.raw_field(raw, name)
    local i, length = 1, #raw
    local function whitespace()
        while i <= length do local c = string.byte(raw, i); if c ~= 32 and c ~= 9 and c ~= 10 and c ~= 13 then break end; i = i + 1 end
    end
    local function string_end()
        assert(string.sub(raw, i, i) == '"', "JSON string required"); i = i + 1
        while i <= length do
            local c = string.sub(raw, i, i); i = i + 1
            if c == "\\" then i = i + 1 elseif c == '"' then return end
        end
        error("unterminated JSON string")
    end
    whitespace(); assert(string.sub(raw, i, i) == "{", "JSON object required"); i = i + 1
    local found
    while true do
        whitespace(); if string.sub(raw, i, i) == "}" then break end
        local start = i; string_end(); local key = json.decode(string.sub(raw, start, i - 1))
        whitespace(); assert(string.sub(raw, i, i) == ":", "JSON colon required"); i = i + 1; whitespace(); start = i
        local depth = 0
        repeat
            local c = string.sub(raw, i, i)
            if c == '"' then string_end()
            elseif c == "{" or c == "[" then depth = depth + 1; i = i + 1
            elseif c == "}" or c == "]" then if depth == 0 then break end; depth = depth - 1; i = i + 1
            elseif c == "," and depth == 0 then break
            else i = i + 1 end
        until i > length
        local ending = i - 1
        while ending >= start do
            local byte = string.byte(raw, ending)
            if byte ~= 32 and byte ~= 9 and byte ~= 10 and byte ~= 13 then break end
            ending = ending - 1
        end
        local value = string.sub(raw, start, ending)
        if key == name then assert(found == nil, "duplicate signed response field"); found = value end
        whitespace(); if string.sub(raw, i, i) == "}" then break end
        assert(string.sub(raw, i, i) == ",", "JSON comma required"); i = i + 1
    end
    return found
end
function M.digits(value)
    assert(type(value) == "string" and #value > 0 and #value <= 19, "integer cents string required")
    for i = 1, #value do local c = string.byte(value, i); assert(c >= 48 and c <= 57, "invalid integer cents") end
    assert(#value == 1 or string.sub(value, 1, 1) ~= "0", "noncanonical integer cents")
    assert(#value < 19 or value <= "9223372036854775807", "cents overflow")
    return value
end
function M.cents(value)
    value = M.digits(value); assert(value ~= "0", "positive cents required"); return value
end
function M.decimal(cents)
    cents = M.cents(cents)
    if #cents == 1 then return "0.0" .. cents end
    if #cents == 2 then return "0." .. cents end
    return string.sub(cents, 1, #cents - 2) .. "." .. string.sub(cents, #cents - 1)
end
function M.from_decimal(raw)
    M.required(raw, "decimal amount required")
    local dot = string.find(raw, ".", 1, true)
    local whole, fraction = raw, "00"
    if dot then
        whole, fraction = string.sub(raw, 1, dot - 1), string.sub(raw, dot + 1)
        assert(#fraction >= 1 and #fraction <= 2, "invalid decimal fraction")
        if #fraction == 1 then fraction = fraction .. "0" end
    end
    assert(#whole > 0 and #whole <= 17, "invalid decimal amount")
    local value = whole .. fraction
    for i = 1, #value do local c = string.byte(value, i); assert(c >= 48 and c <= 57, "invalid decimal amount") end
    while #value > 1 and string.sub(value, 1, 1) == "0" do value = string.sub(value, 2) end
    return M.cents(value)
end
function M.equal_amount(actual, expected)
    actual = M.cents(actual)
    if expected ~= nil then assert(actual == M.cents(expected), "amount mismatch") end
    return actual
end
function M.url(value)
    value = tostring(value); local out = {}
    for i = 1, #value do
        local b = string.byte(value, i)
        if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b == 45 or b == 46 or b == 95 or b == 126 then
            out[#out + 1] = string.char(b)
        else out[#out + 1] = string.format("%%%02X", b) end
    end
    return table.concat(out)
end
function M.unurl(value)
    local out, i = {}, 1
    while i <= #value do
        local c = string.sub(value, i, i)
        if c == "%" then
            local hex = string.sub(value, i + 1, i + 2)
            assert(#hex == 2, "invalid form escape")
            local b = tonumber(hex, 16); assert(b ~= nil, "invalid form escape")
            out[#out + 1] = string.char(b); i = i + 3
        else out[#out + 1] = c == "+" and " " or c; i = i + 1 end
    end
    return table.concat(out)
end
function M.base64(value) return M.value("encoding.base64_encode", {data = value}) end
function M.unbase64(value) return M.value("encoding.base64_decode", {data = value}) end
function M.sorted_keys(values)
    local keys = {}; for k in pairs(values) do keys[#keys + 1] = k end; table.sort(keys); return keys
end
function M.form(values)
    local parts = {}
    for _, k in ipairs(M.sorted_keys(values)) do
        local v = values[k]
        if v ~= nil and tostring(v) ~= "" then parts[#parts + 1] = M.url(k) .. "=" .. M.url(v) end
    end
    return table.concat(parts, "&")
end
function M.parse_form(raw, values)
    values = values or {}; local offset = 1
    while offset <= #raw do
        local stop = string.find(raw, "&", offset, true) or (#raw + 1)
        local part = string.sub(raw, offset, stop - 1)
        if part ~= "" then
            local eq = string.find(part, "=", 1, true)
            local k, v = M.unurl(eq and string.sub(part, 1, eq - 1) or part), M.unurl(eq and string.sub(part, eq + 1) or "")
            assert(k ~= "" and values[k] == nil, "ambiguous callback parameter")
            values[k] = v
        end
        offset = stop + 1
    end
    return values
end
function M.callback_form(p)
    assert(p.method == "GET" or p.method == "POST", "unsupported callback method")
    return M.parse_form(M.unbase64(p.bodyBase64 or ""), M.parse_form(p.query or ""))
end
function M.add_query(raw, key, value)
    M.required(raw); M.required(value)
    assert(not string.find(raw, "#", 1, true), "callback URL must not contain a fragment")
    local query = string.find(raw, "?", 1, true)
    local base, values = raw, {}
    if query then base = string.sub(raw, 1, query - 1); values = M.parse_form(string.sub(raw, query + 1)) end
    assert(values[key] == nil or values[key] == value, "callback hint differs from bound identity")
    values[key] = value
    return base .. "?" .. M.form(values)
end
function M.canonical(values, excluded)
    local parts = {}
    for _, k in ipairs(M.sorted_keys(values)) do
        local v = values[k]
        if not excluded[k] and v ~= nil and tostring(v) ~= "" then parts[#parts + 1] = k .. "=" .. tostring(v) end
    end
    return table.concat(parts, "&")
end
function M.header(headers, name)
    local value
    for k, v in pairs(headers or {}) do
        if string.lower(k) == string.lower(name) then
            assert(value == nil, "duplicate response header")
            if type(v) == "table" then assert(#v == 1, "ambiguous response header"); v = v[1] end
            value = v
        end
    end
    return value
end
function M.http(request)
    local response = M.call("https.request", request)
    assert(type(response.status) == "number" and response.status >= 200 and response.status < 300, "provider outcome unknown: HTTP failure")
    return response
end
function M.now() return M.call("clock.now", {}) end
function M.nonce() return M.value("random.bytes", {size = 24, encoding = "hex"}) end
function M.time(raw)
    if not raw or raw == "" then return nil end
    return M.value("time.parse", {value = raw, layout = "2006-01-02 15:04:05", offsetSeconds = 28800})
end
function M.created(request, launch)
    local p = json.decode(request.payload)
    local binding = request.binding or {pluginId = M.required(request.pluginId), pluginVersion = M.required(request.version),
        orderNo = M.required(p.orderNo), product = M.required(p.product), amountCents = M.cents(p.amountCents), currency = "CNY"}
    return json.encode({binding = binding, product = binding.product, launch = launch})
end
function M.ack(kind)
    if kind == "wechat" then return {statusCode = 200, contentType = "application/json", body = '{"code":"SUCCESS","message":"成功"}'} end
    return {statusCode = 200, contentType = "text/plain; charset=utf-8", body = "success"}
end
return M
