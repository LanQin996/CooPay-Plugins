local U, A = require("lib.util"), require("lib.alipay")
local states = {TRADE_SUCCESS = "paid", TRADE_FINISHED = "paid", TRADE_CLOSED = "closed", WAIT_BUYER_PAY = "pending"}
local function order(r, p)
    assert(r.out_trade_no == p.orderNo, "Alipay order mismatch")
    local status = states[r.trade_status] or "unknown"
    local result = {orderNo = r.out_trade_no, paymentNo = r.trade_no, status = status, verified = status ~= "unknown",
        amountCents = U.equal_amount(U.from_decimal(r.total_amount), p.amountCents), paidAt = U.time(r.send_pay_date or r.gmt_payment)}
    if status == "paid" then U.required(result.paymentNo); U.required(result.paidAt) end
    return result
end
function handle(request)
    if request.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then A.check(c); return json.encode({valid = true}) end
    if request.capability == "payment.create" then
        local biz = {out_trade_no = U.required(p.orderNo), total_amount = U.decimal(p.amountCents), subject = U.required(p.description)}
        if p.product == "face_to_face" then
            local r = A.request(c, "alipay.trade.precreate", biz, U.required(p.callbackUrl))
            assert(r.out_trade_no == nil or r.out_trade_no == p.orderNo, "Alipay precreate identity mismatch")
            return U.created(request, {type = "qr", qr = {content = U.required(r.qr_code)}})
        end
        local method
        if p.product == "website" then method, biz.product_code = "alipay.trade.page.pay", "FAST_INSTANT_TRADE_PAY"
        elseif p.product == "mobile_website" then method, biz.product_code = "alipay.trade.wap.pay", "QUICK_WAP_WAY"
        else error("unsupported Alipay product") end
        if p.legacyQr then
            if p.product == "website" then biz.qr_pay_mode = "4" end
            local qr = A.page_qr(c, method, biz, U.required(p.callbackUrl))
            return U.created(request, {type = "qr", qr = {content = qr}})
        end
        local fields = A.parameters(c, method, biz, U.required(p.callbackUrl))
        -- The gateway selects the POST decoder from the URL charset. A hidden
        -- charset field alone can leave UTF-8 subjects interpreted as GBK.
        local action = U.add_query(A.gateway(c), "charset", "utf-8")
        return U.created(request, {type = "form", form = {method = "POST", action = action, fields = fields}})
    elseif request.capability == "payment.query" then
        return json.encode(order(A.request(c, "alipay.trade.query", {out_trade_no = U.required(p.orderNo)}), p))
    elseif request.capability == "payment.callback" then
        local form = A.callback_form(p)
        U.required(form.out_trade_no)
        if p.phase == "identify" then return json.encode({orderNo = form.out_trade_no}) end
        assert(p.phase == "verify", "invalid callback phase")
        A.verify_callback(c, form)
        local result = order(form, {orderNo = form.out_trade_no})
        assert(result.status == "paid", "callback is not a successful payment")
        result.ack = U.ack(); return json.encode(result)
    elseif request.capability == "refund.create" then
        local r = A.request(c, "alipay.trade.refund", {out_trade_no = U.required(p.orderNo), out_request_no = U.required(p.refundNo),
            refund_amount = U.decimal(p.amountCents), refund_reason = p.reason or ""})
        assert(r.out_trade_no == p.orderNo and (r.fund_change == "Y" or r.fund_change == "N"), "Alipay refund identity/status mismatch")
        U.required(r.trade_no, "missing Alipay refund trade identity")
        return json.encode({orderNo = r.out_trade_no, refundNo = p.refundNo, providerRefundNo = p.refundNo,
            amountCents = U.equal_amount(U.from_decimal(r.refund_fee), p.amountCents), status = "success", verified = true})
    elseif request.capability == "refund.query" then
        local r = A.request(c, "alipay.trade.fastpay.refund.query", {out_trade_no = U.required(p.orderNo), out_request_no = U.required(p.refundNo)})
        assert(r.out_trade_no == p.orderNo and r.out_request_no == p.refundNo, "Alipay refund identity mismatch")
        U.required(r.trade_no, "missing Alipay refund trade identity")
        local status = r.refund_status == "REFUND_SUCCESS" and "success" or "unknown"
        return json.encode({orderNo = r.out_trade_no, refundNo = r.out_request_no, providerRefundNo = r.out_request_no,
            amountCents = U.equal_amount(U.from_decimal(r.refund_amount), p.amountCents), totalCents = U.from_decimal(r.total_amount),
            status = status, verified = status ~= "unknown", successAt = U.time(r.gmt_refund_pay)})
    end
    error("unsupported capability")
end
