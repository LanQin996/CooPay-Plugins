local U = require("lib.util")
local M = {}
function M.validate(c)
    for _, k in ipairs({"appid", "private_key", "alipay_public_key"}) do U.required(c[k], k .. " required") end
end
function M.gateway(c)
    return c.gateway_url and c.gateway_url ~= "" and c.gateway_url or "https://openapi.alipay.com/gateway.do"
end
function M.check(c)
    M.validate(c)
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key, data = "CooPay plugin key validation", encoding = "base64"})
    U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key, data = "CooPay plugin key validation", signature = signature, encoding = "base64"})
end
function M.parameters(c, method, biz, notify)
    M.validate(c)
    local p = {app_id = c.appid, method = method, format = "JSON", charset = "utf-8", sign_type = "RSA2",
        timestamp = U.value("time.format", {unix = U.now().unix, layout = "2006-01-02 15:04:05", offsetSeconds = 28800}),
        version = "1.0", biz_content = json.encode(biz)}
    if notify then p.notify_url = notify end
    p.sign = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key,
        data = U.canonical(p, {sign = true}), encoding = "base64"})
    return p
end
local function resolve(base, location)
    U.required(location, "missing Alipay redirect location")
    assert(not string.find(location, "\\", 1, true), "invalid Alipay redirect location")
    for i = 1, #location do
        local byte = string.byte(location, i)
        assert(byte >= 32 and byte ~= 127, "invalid Alipay redirect location")
    end
    assert(not string.find(location, "#", 1, true), "Alipay redirect fragments are not allowed")
    if string.sub(location, 1, 8) == "https://" then return location end
    assert(string.sub(location, 1, 7) ~= "http://" and string.sub(location, 1, 2) ~= "//", "insecure Alipay redirect")
    local origin_end = string.find(base, "/", 9, true) or (#base + 1)
    local origin = string.sub(base, 1, origin_end - 1)
    if string.sub(location, 1, 1) == "/" then return origin .. location end
    local path_end = string.find(base, "?", 1, true) or string.find(base, "#", 1, true) or (#base + 1)
    local path = string.sub(base, 1, path_end - 1)
    local slash
    for i = #path, 1, -1 do
        if string.sub(path, i, i) == "/" then slash = i; break end
    end
    return string.sub(path, 1, slash or #path) .. location
end
local function html_attribute(tag, attribute)
    local start = string.find(tag, attribute .. "=", 1, true)
    if not start then return nil end
    local i = start + #attribute + 1
    while string.sub(tag, i, i) == " " or string.sub(tag, i, i) == "\t" do i = i + 1 end
    local quote = string.sub(tag, i, i)
    if quote ~= "'" and quote ~= '"' then return nil end
    local finish = string.find(tag, quote, i + 1, true)
    if not finish then return nil end
    return string.sub(tag, i + 1, finish - 1)
end
local function html_unescape(value)
    local output, cursor = {}, 1
    while true do
        local start = string.find(value, "&amp;", cursor, true)
        if not start then output[#output + 1] = string.sub(value, cursor); break end
        output[#output + 1] = string.sub(value, cursor, start - 1)
        output[#output + 1] = "&"
        cursor = start + 5
    end
    return table.concat(output)
end
function M.page_qr(c, method, biz, notify)
    local fields = M.parameters(c, method, biz, notify)
    local current = U.add_query(M.gateway(c), "charset", "utf-8")
    fields.charset = nil
    current = current .. "&" .. U.form(fields)
    for _ = 1, 6 do
        local response = U.call("https.request", {method = "GET", url = current, headers = {Accept = "text/html"}, body = ""})
        assert(type(response.status) == "number", "invalid Alipay page response")
        if response.status >= 200 and response.status < 300 then
            local html = U.required(response.body, "empty Alipay payment page")
            local qr
            local field = string.find(html, "qrCode", 1, true)
            if field then
                local tag_start
                for i = field, 1, -1 do
                    if string.sub(html, i, i) == "<" then tag_start = i; break end
                    if string.sub(html, i, i) == ">" then break end
                end
                local tag_end = string.find(html, ">", field, true)
                if tag_start and tag_end then
                    local tag = string.sub(html, tag_start, tag_end)
                    local id, name = html_attribute(tag, "id"), html_attribute(tag, "name")
                    if id == "qrCode" or name == "qrCode" then qr = html_attribute(tag, "value") end
                end
            end
            qr = qr and html_unescape(qr)
            assert(qr and string.sub(qr, 1, 22) == "https://qr.alipay.com/", "Alipay payment page did not contain a native QR code")
            return qr
        end
        assert(response.status == 301 or response.status == 302 or response.status == 303 or response.status == 307 or response.status == 308, "Alipay payment page request failed")
        local location = U.header(response.headers, "location")
        current = resolve(current, U.required(location, "Alipay redirect missing location"))
    end
    error("too many Alipay payment page redirects")
end
function M.request(c, method, biz, notify)
    local p = M.parameters(c, method, biz, notify)
    local response = U.http({method = "POST", url = M.gateway(c), body = U.form(p),
        headers = {["Content-Type"] = "application/x-www-form-urlencoded;charset=utf-8", Accept = "application/json"}})
    local envelope = U.decode(response.body)
    local response_name = ""
    for i = 1, #method do local ch = string.sub(method, i, i); response_name = response_name .. (ch == "." and "_" or ch) end
    response_name = response_name .. "_response"
    local raw = U.required(U.raw_field(response.body, response_name), "missing signed Alipay response")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key,
        data = raw, signature = U.required(envelope.sign), encoding = "base64"}) == true, "invalid Alipay response signature")
    local result = U.decode(raw)
    assert(result.code == "10000", "Alipay operation rejected or outcome unknown")
    return result
end
function M.verify_callback(c, p)
    M.validate(c)
    assert(p.sign_type == "RSA2", "unsupported Alipay signature type")
    assert(p.app_id == c.appid and (not c.pid or c.pid == "" or p.seller_id == c.pid), "Alipay merchant identity mismatch")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.alipay_public_key,
        data = U.canonical(p, {sign = true, sign_type = true}), signature = U.required(p.sign), encoding = "base64"}) == true, "invalid Alipay callback signature")
end
return M
