local U = require("lib.util")
local function enabled(c)
    assert(c.debug_enabled == "true" or c.DebugEnabled == true, "debug real-name provider is disabled")
end
function handle(r)
    if r.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(r), json.decode(r.payload)
    enabled(c)
    if r.capability == "config.validate" then return json.encode({valid = true}) end
    if r.capability == "realname.start" then
        U.required(p.name); U.required(p.idCard)
        local token, callback = U.nonce(), U.required(p.callbackUrl)
        assert(not string.find(callback, "#", 1, true), "debug callback must not contain a fragment")
        local query_start = string.find(callback, "?", 1, true)
        local base, values = callback, {}
        if query_start then base = string.sub(callback, 1, query_start - 1); values = U.parse_form(string.sub(callback, query_start + 1)) end
        values.AuthToken = token
        return json.encode({AuthToken = token, RedirectURL = base .. "?" .. U.form(values)})
    elseif r.capability == "realname.query" then
        U.required(p.authToken)
        return json.encode({Status = "PASSED", ResultType = "0", Message = "debug real-name authentication passed"})
    end
    error("unsupported capability")
end
