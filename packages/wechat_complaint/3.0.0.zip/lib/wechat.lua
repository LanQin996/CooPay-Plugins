local U = require("lib.util")
local M = {}
function M.validate(c)
    for _, k in ipairs({"merchant_id", "appid", "public_key_id", "public_key_pem", "private_key_pem", "merchant_serial_number", "api_v3_key"}) do U.required(c[k], k .. " required") end
    assert(#c.api_v3_key == 32, "API v3 key must have 32 bytes")
end
function M.verify(c, headers, body, blob_id)
    local serial = U.header(headers, "Wechatpay-Serial")
    local timestamp = U.header(headers, "Wechatpay-Timestamp")
    local nonce = U.header(headers, "Wechatpay-Nonce")
    local signature = U.header(headers, "Wechatpay-Signature")
    assert(serial == c.public_key_id, "untrusted WeChat signing key")
    U.required(timestamp); U.required(nonce); U.required(signature)
    local ts = tonumber(timestamp)
    assert(ts and math.abs(U.now().unix - ts) <= 300, "expired WeChat signature")
    local input = {algorithm = "sha256", publicKey = c.public_key_pem, signature = signature, encoding = "base64"}
    if blob_id then input.dataPrefix = timestamp .. "\n" .. nonce .. "\n"; input.blobId = blob_id; input.dataSuffix = "\n"
    else input.data = timestamp .. "\n" .. nonce .. "\n" .. body .. "\n" end
    assert(U.value("crypto.rsa_verify", input) == true, "invalid WeChat signature")
end
function M.check(c)
    M.validate(c)
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem, data = "CooPay plugin key validation", encoding = "base64"})
    -- The merchant and platform keys are different. The boolean is irrelevant;
    -- completing this operation proves the platform public key parsed safely.
    U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.public_key_pem, data = "CooPay plugin key validation", signature = signature, encoding = "base64"})
end
function M.headers(c, method, target, body)
    M.validate(c); body = body or ""
    local timestamp, nonce = tostring(U.now().unix), U.value("random.bytes", {size = 16, encoding = "hex"})
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem,
        data = method .. "\n" .. target .. "\n" .. timestamp .. "\n" .. nonce .. "\n" .. body .. "\n", encoding = "base64"})
    local authorization = 'WECHATPAY2-SHA256-RSA2048 mchid="' .. c.merchant_id .. '",nonce_str="' .. nonce .. '",timestamp="' .. timestamp .. '",serial_no="' .. c.merchant_serial_number .. '",signature="' .. signature .. '"'
    return {Authorization = authorization, Accept = "application/json", ["Content-Type"] = "application/json", ["Wechatpay-Serial"] = c.public_key_id}
end
function M.request(c, method, target, body, raw_result, response_blob, allow_not_found)
    body = body or ""
    local r = U.call("https.request", {method = method, url = "https://api.mch.weixin.qq.com" .. target, body = body,
        headers = M.headers(c, method, target, body), responseBlob = response_blob or nil})
    if response_blob then
        assert(type(r.status) == "number" and r.status >= 200 and r.status < 300, "WeChat image download failed")
        M.verify(c, r.headers, nil, U.required(r.blobId)); return r
    end
    M.verify(c, r.headers, r.body)
    if allow_not_found and r.status == 404 then return {url = "", notFound = true} end
    assert(type(r.status) == "number" and r.status >= 200 and r.status < 300, "WeChat complaint outcome unknown")
    if raw_result then return r.body end
    if r.body == "" then return {} end
    return U.decode(r.body)
end
function M.notification(c, p)
    assert(p.method == "POST", "WeChat notification requires POST")
    M.validate(c)
    local body = U.unbase64(U.required(p.bodyBase64))
    M.verify(c, p.headers, body)
    local envelope = U.decode(body)
    assert(type(envelope.resource) == "table" and envelope.resource.algorithm == "AEAD_AES_256_GCM", "unsupported notification encryption")
    local r = envelope.resource
    local plain = U.value("crypto.aes_gcm_decrypt", {key = c.api_v3_key, nonce = r.nonce,
        associatedData = r.associated_data or "", ciphertext = r.ciphertext})
    return U.decode(plain), envelope.event_type, envelope
end
function M.upload(c, p)
    local id = U.required(p.blobId)
    local info = U.call("blob.info", {id = id})
    assert(type(info.size) == "number" and info.size > 0 and info.size <= 2097152, "complaint image exceeds 2 MiB")
    local extensions = {["image/png"] = ".png", ["image/jpeg"] = ".jpg", ["image/bmp"] = ".bmp"}
    assert(extensions[info.contentType], "unsupported complaint image type")
    assert(not p.contentType or p.contentType == "" or p.contentType == info.contentType, "image content type mismatch")
    local filename = "complaint-image" .. extensions[info.contentType]
    local meta = json.encode({filename = filename, sha256 = U.value("blob.digest", {id = id, algorithm = "sha256"})})
    local target = "/v3/merchant-service/images/upload"
    local headers = M.headers(c, "POST", target, meta); headers["Content-Type"] = nil
    local response = U.call("https.multipart", {url = "https://api.mch.weixin.qq.com" .. target, method = "POST", headers = headers,
        fields = {meta = meta}, fieldContentTypes = {meta = "application/json"},
        parts = {{name = "file", filename = filename, contentType = info.contentType, blobId = id}}})
    assert(type(response.status) == "number" and response.status >= 200 and response.status < 300, "complaint image upload outcome unknown")
    M.verify(c, response.headers, response.body)
    local result = U.decode(response.body)
    return {mediaId = U.required(result.media_id), mediaType = info.contentType}
end
return M
