local U, W = require("lib.util"), require("lib.wechat")
local base = "/v3/merchant-service/complaints-v2"
local function identifier(value)
    U.required(value); assert(#value <= 64, "complaint identifier too long")
    for i = 1, #value do local b = string.byte(value, i); assert((b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) or b == 45 or b == 95, "invalid complaint identifier") end
    return value
end
local function text(value, maximum, required)
    if value == nil or value == "" then assert(not required, "complaint text required"); return nil end
    U.required(value); local length = 0
    for i = 1, #value do local b = string.byte(value, i); if b < 128 or b >= 192 then length = length + 1 end end
    assert(length <= maximum, "complaint text too long"); return value
end
local function media(items)
    if items == nil or #items == 0 then return nil end
    assert(#items <= 4, "too many complaint media IDs")
    for _, item in ipairs(items) do U.required(item); assert(#item <= 512, "media ID too long") end
    return items
end
local function pagination(p, maximum)
    assert(type(p.limit) == "number" and p.limit >= 1 and p.limit <= maximum and p.limit == math.floor(p.limit), "invalid complaint page limit")
    assert(type(p.offset) == "number" and p.offset >= 0 and p.offset == math.floor(p.offset), "invalid complaint page offset")
end
local function civil_day(value)
    local y, m, d = tonumber(string.sub(value, 1, 4)), tonumber(string.sub(value, 6, 7)), tonumber(string.sub(value, 9, 10))
    if m <= 2 then y = y - 1 end
    local era = math.floor(y / 400)
    local year = y - era * 400
    local month = m + (m > 2 and -3 or 9)
    return era * 146097 + year * 365 + math.floor(year / 4) - math.floor(year / 100) + math.floor((153 * month + 2) / 5) + d - 1
end
function handle(request)
    if request.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then W.check(c); return json.encode({valid = true}) end
    if request.capability == "complaint.callback" then
        local r, event, envelope = W.notification(c, p)
        assert(event == "COMPLAINT.CREATE" or event == "COMPLAINT.STATE_CHANGE", "unsupported complaint notification event")
        assert(envelope.resource_type == "encrypt-resource" and #identifier(envelope.id) <= 36, "invalid complaint notification identity")
        local actions = {CREATE_COMPLAINT = true, CONTINUE_COMPLAINT = true, USER_RESPONSE = true, RESPONSE_BY_PLATFORM = true,
            SELLER_REFUND = true, MERCHANT_RESPONSE = true, MERCHANT_CONFIRM_COMPLETE = true, USER_APPLY_PLATFORM_SERVICE = true,
            USER_CANCEL_PLATFORM_SERVICE = true, PLATFORM_SERVICE_FINISHED = true, MERCHANT_APPROVE_REFUND = true,
            MERCHANT_REJECT_REFUND = true, REFUND_SUCCESS = true}
        assert(actions[r.action_type], "unsupported complaint notification action")
        assert(not r.mchid or r.mchid == c.merchant_id, "complaint notification merchant mismatch")
        return json.encode({complaintId = identifier(r.complaint_id), actionType = r.action_type, verified = true, ack = U.ack("wechat")})
    end
    if request.capability == "complaint.query" and p.operation == "media_download" then
        local media_id = U.required(p.mediaId)
        assert(#media_id <= 512, "media id too long")
        for i = 1, #media_id do local ch = string.sub(media_id, i, i); assert((ch >= "a" and ch <= "z") or (ch >= "A" and ch <= "Z") or (ch >= "0" and ch <= "9") or ch == "_" or ch == "-" or ch == ".", "invalid media id") end
        local response = W.request(c, "GET", "/v3/merchant-service/images/" .. media_id, nil, false, true)
        local info = U.call("blob.info", {id = response.blobId})
        assert(type(info.size) == "number" and info.size > 0 and info.size <= 10485760, "downloaded complaint image exceeds 10 MiB")
        assert(info.contentType == "image/jpeg" or info.contentType == "image/png" or info.contentType == "image/bmp", "invalid downloaded image type")
        return json.encode({mediaId = media_id, mediaType = info.contentType, blobId = response.blobId, downloaded = true})
    end
    if request.capability == "complaint.handle" and p.operation == "media_upload" then
        return json.encode(W.upload(c, p))
    end
    if (request.capability == "complaint.query" and p.operation == "notification_get") or
       (request.capability == "complaint.handle" and (p.operation == "notification_create" or p.operation == "notification_update")) then
        local method, body = "GET", nil
        if p.operation ~= "notification_get" then
            U.required(p.url); assert(#p.url <= 2048 and string.sub(p.url, 1, 8) == "https://" and not string.find(p.url, "#", 1, true), "invalid complaint notification URL")
            method = p.operation == "notification_create" and "POST" or "PUT"; body = json.encode({url = p.url})
        end
        local result = W.request(c, method, "/v3/merchant-service/complaint-notifications", body, false, false, p.operation == "notification_get")
        if result.notFound then return json.encode(result) end
        U.required(result.url); assert(string.sub(result.url, 1, 8) == "https://" and (not body or result.url == p.url), "complaint notification URL response mismatch")
        return json.encode({url = result.url})
    end
    if request.capability == "complaint.query" then
        local target
        if p.operation == "get" then target = base .. "/" .. identifier(p.complaintId)
        elseif p.operation == "list" then
            pagination(p, 50); U.required(p.beginDate); U.required(p.endDate)
            U.value("time.parse", {value = p.beginDate, layout = "2006-01-02", offsetSeconds = 0})
            U.value("time.parse", {value = p.endDate, layout = "2006-01-02", offsetSeconds = 0})
            assert(p.beginDate <= p.endDate, "invalid complaint date range")
            assert(civil_day(p.endDate) - civil_day(p.beginDate) <= 30, "complaint date range exceeds 30 days")
            assert(not p.complaintedMerchantId or p.complaintedMerchantId == "" or p.complaintedMerchantId == c.merchant_id, "complaint merchant mismatch")
            target = base .. "?" .. U.form({begin_date = p.beginDate, end_date = p.endDate, limit = p.limit, offset = p.offset, complainted_mchid = c.merchant_id})
        elseif p.operation == "history" then
            pagination(p, 300); target = base .. "/" .. identifier(p.complaintId) .. "/negotiation-historys?" .. U.form({limit = p.limit, offset = p.offset})
        else error("unsupported complaint query operation") end
        local raw = W.request(c, "GET", target, nil, true)
        local response = U.decode(raw)
        if p.operation == "get" then
            assert(response.complaint_id == p.complaintId and response.complainted_mchid == c.merchant_id, "complaint identity mismatch")
        else
            assert(tonumber(response.limit) == p.limit and tonumber(response.offset) == p.offset and tonumber(response.total_count) >= 0, "complaint pagination mismatch")
            assert(type(response.data) == "table" and #response.data <= p.limit, "invalid complaint page")
            assert(#response.data == 0 or (p.offset <= tonumber(response.total_count) and #response.data <= tonumber(response.total_count) - p.offset), "inconsistent complaint total count")
            local seen = {}
            for _, item in ipairs(response.data) do
                local id = identifier(p.operation == "list" and item.complaint_id or item.log_id)
                assert(not seen[id], "duplicate complaint page item"); seen[id] = true
                assert(not item.complainted_mchid or item.complainted_mchid == c.merchant_id, "complaint page merchant mismatch")
                if p.operation == "history" then identifier(item.operate_type) end
            end
        end
        -- Return signed provider JSON bytes unchanged: numeric complaint amounts
        -- must reach Go int64 without a Lua float conversion.
        return raw
    elseif request.capability == "complaint.handle" then
        local target, body = base .. "/" .. identifier(p.complaintId), {}
        if p.operation == "immediate_reply" then
            identifier(p.idempotencyId)
            assert(type(p.messageBlocks) == "table" and #p.messageBlocks >= 1 and #p.messageBlocks <= 20, "invalid immediate reply blocks")
            local nodes = 0
            local function validate(value, depth)
                nodes = nodes + 1; assert(nodes <= 512 and depth <= 8, "immediate reply is too complex")
                if value == json.null then return end
                local kind = type(value)
                if kind == "table" then
                    local count = 0
                    for k, v in pairs(value) do
                        count = count + 1
                        if type(k) == "string" then text(k, 64, true); for i = 1, #k do assert(string.byte(k, i) >= 32, "invalid block key") end end
                        validate(v, depth + 1)
                    end
                    assert(count <= (#value > 0 and 64 or 32), "oversized immediate reply block")
                elseif kind == "string" then text(value, 2000, false)
                else assert(kind == "boolean" or kind == "number", "invalid immediate reply value") end
            end
            for _, block in ipairs(p.messageBlocks) do assert(type(block) == "table", "message block must be an object"); validate(block, 1) end
            local raw_blocks = U.required(U.raw_field(request.payload, "messageBlocks")); assert(#raw_blocks <= 16384, "immediate reply exceeds 16 KiB")
            local raw = '{"complainted_mchid":' .. json.encode(c.merchant_id) .. ',"idempotent_id":' .. json.encode(p.idempotencyId) .. ',"message":{"blocks":' .. raw_blocks .. '}}'
            local result = W.request(c, "POST", target .. "/response-immediate-service", raw)
            return json.encode({logId = identifier(result.log_id)})
        elseif p.operation == "reply" then
            target = target .. "/response"
            body = {complainted_mchid = c.merchant_id, response_content = text(p.content, 500, true), response_images = media(p.mediaIds),
                jump_url = text(p.url, 512, false), jump_url_text = text(p.urlText, 10, false)}
            if body.jump_url then assert(string.sub(body.jump_url, 1, 8) == "https://", "complaint jump URL must use HTTPS") end
            if p.miniProgramAppId and p.miniProgramAppId ~= "" then
                body.mini_program_jump_info = {appid = U.required(p.miniProgramAppId), path = text(p.miniProgramPath, 512, true), text = text(p.miniProgramDisplay, 50, true)}
            end
        elseif p.operation == "refund_progress" then
            assert(type(p.accept) == "boolean", "refund decision required")
            target = target .. "/update-refund-progress"
            body = {action = p.accept and "APPROVE" or "REJECT", remark = text(p.reason, 200, false)}
            if p.accept then body.launch_refund_day = 0 else body.reject_reason = text(p.reason, 200, true); body.reject_media_list = media(p.mediaIds) end
        elseif p.operation == "complete" then target = target .. "/complete"; body = {complainted_mchid = c.merchant_id}
        else error("unsupported complaint handle operation") end
        W.request(c, "POST", target, json.encode(body))
        return json.encode({ok = true})
    end
    error("unsupported capability")
end
