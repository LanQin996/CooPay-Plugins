local U = require("lib.util")
local function credentials(c)
    local region = c.region_id or c.RegionID
    if not region or region == "" then region = "cn-hangzhou" end
    return U.required(c.access_key_id or c.AccessKeyID), U.required(c.access_key_secret or c.AccessKeySecret),
        U.required(c.sign_name or c.SignName), region
end
function handle(r)
    if r.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(r), json.decode(r.payload)
    if r.capability == "config.validate" then credentials(c); return json.encode({valid = true}) end
    assert(r.capability == "sms.send", "unsupported capability")
    local id, key, sign_name, region = credentials(c)
    local params = {AccessKeyId = id, Action = "SendSms", Format = "JSON", PhoneNumbers = U.required(p.phone),
        RegionId = region, SignatureMethod = "HMAC-SHA1", SignatureNonce = U.nonce(), SignatureVersion = "1.0",
        SignName = sign_name, TemplateCode = U.required(p.templateCode), TemplateParam = json.encode({code = U.required(p.code)}),
        Timestamp = U.now().iso8601, Version = "2017-05-25"}
    params.Signature = U.value("crypto.hmac", {algorithm = "sha1", key = key .. "&", data = "POST&%2F&" .. U.url(U.form(params)), encoding = "base64"})
    local result = U.decode(U.http({method = "POST", url = "https://dysmsapi.aliyuncs.com/", body = U.form(params),
        headers = {["Content-Type"] = "application/x-www-form-urlencoded", Accept = "application/json"}}).body)
    return json.encode({ok = result.Code == "OK", code = result.Code, requestId = result.RequestId})
end
