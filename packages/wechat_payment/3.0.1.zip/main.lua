local U, W = require("lib.util"), require("lib.wechat")
local payment_states = {SUCCESS = "paid", CLOSED = "closed", REVOKED = "closed", PAYERROR = "closed", NOTPAY = "pending", USERPAYING = "pending"}
local refund_states = {SUCCESS = "success", PROCESSING = "pending", ABNORMAL = "pending", CLOSED = "failed"}
local function identity(c, r)
    assert(r.mchid == c.merchant_id and (r.appid == nil or r.appid == c.appid), "WeChat merchant identity mismatch")
end
local function payment(c, r, p)
    identity(c, r)
    assert(r.trade_type == "NATIVE" and (not p.product or p.product == "native"), "WeChat payment product mismatch")
    assert(type(r.amount) == "table" and r.amount.currency == "CNY", "unsupported WeChat payment currency")
    U.required(r.out_trade_no)
    assert(not p.orderNo or r.out_trade_no == p.orderNo, "WeChat order mismatch")
    local status = payment_states[r.trade_state] or "unknown"
    local result = {orderNo = r.out_trade_no, paymentNo = r.transaction_id or "", status = status,
        amountCents = U.equal_amount(r.amount.total, p.amountCents), paidAt = r.success_time, verified = status ~= "unknown"}
    if status == "paid" then U.required(result.paymentNo); U.required(result.paidAt) end
    return result
end
local function refund(c, r, p)
    assert(r.mchid == nil or r.mchid == c.merchant_id, "WeChat refund merchant mismatch")
    assert(r.out_trade_no == p.orderNo and r.out_refund_no == p.refundNo, "WeChat refund identity mismatch")
    assert(type(r.amount) == "table" and r.amount.currency == "CNY", "unsupported WeChat refund currency")
    local status = refund_states[r.status or r.refund_status] or "unknown"
    return {orderNo = r.out_trade_no, refundNo = r.out_refund_no, providerRefundNo = r.refund_id,
        status = status, verified = status ~= "unknown", amountCents = U.equal_amount(r.amount.refund, p.amountCents),
        totalCents = U.equal_amount(r.amount.total, p.totalCents), successAt = r.success_time}
end
function handle(request)
    if request.capability == "health" then return json.encode({ok = true}) end
    local c, p = U.config(request), json.decode(request.payload)
    if request.capability == "config.validate" then
        local valid, diagnosticCode = W.check(c)
        return json.encode({valid = valid, diagnosticCode = diagnosticCode})
    end
    if request.capability == "payment.create" then
        assert(p.product == "native", "unsupported WeChat product")
        local notify = U.add_query(p.callbackUrl, "orderNo", U.required(p.orderNo))
        local body = '{"appid":' .. json.encode(c.appid) .. ',"mchid":' .. json.encode(c.merchant_id) ..
            ',"description":' .. json.encode(U.required(p.description)) .. ',"out_trade_no":' .. json.encode(p.orderNo) ..
            ',"notify_url":' .. json.encode(notify) .. ',"attach":' .. json.encode(p.attach or "") ..
            ',"amount":{"total":' .. U.cents(p.amountCents) .. ',"currency":"CNY"}}'
        local r = W.request(c, "POST", "/v3/pay/transactions/native", body)
        return U.created(request, {type = "qr", qr = {content = U.required(r.code_url)}})
    elseif request.capability == "payment.query" then
        local r = W.request(c, "GET", "/v3/pay/transactions/out-trade-no/" .. U.url(U.required(p.orderNo)) .. "?mchid=" .. U.url(c.merchant_id))
        return json.encode(payment(c, r, p))
    elseif request.capability == "refund.create" then
        local notify = U.add_query(p.callbackUrl, "refundNo", U.required(p.refundNo))
        local body = '{"out_trade_no":' .. json.encode(U.required(p.orderNo)) .. ',"out_refund_no":' .. json.encode(p.refundNo) ..
            ',"reason":' .. json.encode(p.reason or "") .. ',"notify_url":' .. json.encode(notify) ..
            ',"amount":{"refund":' .. U.cents(p.amountCents) .. ',"total":' .. U.cents(p.totalCents) .. ',"currency":"CNY"}}'
        return json.encode(refund(c, W.request(c, "POST", "/v3/refund/domestic/refunds", body), p))
    elseif request.capability == "refund.query" then
        local r = W.request(c, "GET", "/v3/refund/domestic/refunds/" .. U.url(U.required(p.refundNo)), nil, false, true)
        if r.notFound then
            return json.encode({orderNo = U.required(p.orderNo), refundNo = p.refundNo, amountCents = U.cents(p.amountCents),
                totalCents = U.cents(p.totalCents), status = "not_found", verified = true})
        end
        return json.encode(refund(c, r, p))
    elseif request.capability == "payment.callback" or request.capability == "refund.callback" then
        local is_refund = request.capability == "refund.callback"
        local hints = U.parse_form(p.query or "")
        local key = is_refund and "refundNo" or "orderNo"
        U.required(hints[key], "missing callback hint")
        if p.phase == "identify" then return json.encode({[key] = hints[key]}) end
        assert(p.phase == "verify", "invalid callback phase")
        local r, event = W.notification(c, p)
        local result
        if is_refund then
            assert(event == "REFUND.SUCCESS" or event == "REFUND.ABNORMAL" or event == "REFUND.CLOSED", "unsupported refund event")
            assert(r.out_refund_no == hints.refundNo, "refund callback hint mismatch")
            result = refund(c, r, {orderNo = r.out_trade_no, refundNo = hints.refundNo})
        else
            assert(event == "TRANSACTION.SUCCESS" and r.trade_state == "SUCCESS", "unsupported payment event")
            assert(r.out_trade_no == hints.orderNo, "payment callback hint mismatch")
            result = payment(c, r, {orderNo = hints.orderNo})
        end
        result.ack = U.ack("wechat"); return json.encode(result)
    end
    error("unsupported capability")
end
