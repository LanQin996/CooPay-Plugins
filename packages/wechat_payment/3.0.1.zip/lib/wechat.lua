local U = require("lib.util")
local M = {}
function M.validate(c)
    for _, k in ipairs({"merchant_id", "appid", "public_key_id", "public_key_pem", "private_key_pem", "merchant_serial_number", "api_v3_key"}) do U.required(c[k], k .. " required") end
    assert(#c.api_v3_key == 32, "API v3 key must have 32 bytes")
end
function M.verify(c, headers, body)
    local serial = U.header(headers, "Wechatpay-Serial")
    local timestamp = U.header(headers, "Wechatpay-Timestamp")
    local nonce = U.header(headers, "Wechatpay-Nonce")
    local signature = U.header(headers, "Wechatpay-Signature")
    assert(serial == c.public_key_id, "untrusted WeChat signing key")
    U.required(timestamp); U.required(nonce); U.required(signature)
    local ts = tonumber(timestamp)
    assert(ts and math.abs(U.now().unix - ts) <= 300, "expired WeChat signature")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.public_key_pem,
        data = timestamp .. "\n" .. nonce .. "\n" .. body .. "\n", signature = signature, encoding = "base64"}) == true, "invalid WeChat signature")
end
function M.check(c)
    for _, field in ipairs({"merchant_id", "appid", "public_key_id", "public_key_pem", "private_key_pem", "merchant_serial_number", "api_v3_key"}) do
        if type(c[field]) ~= "string" or #c[field] == 0 or #c[field] > 32768 then
            return false, "missing_" .. field
        end
    end
    if #c.api_v3_key ~= 32 then return false, "invalid_api_v3_key_length" end
    local ok, signature = pcall(U.value, "crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem,
        data = "CooPay plugin key validation", encoding = "base64"})
    if not ok then return false, "merchant_private_key_invalid" end
    -- The merchant and platform keys are different. The boolean is irrelevant;
    -- completing this operation proves the platform public key parsed safely.
    ok = pcall(U.value, "crypto.rsa_verify", {algorithm = "sha256", publicKey = c.public_key_pem,
        data = "CooPay plugin key validation", signature = signature, encoding = "base64"})
    if not ok then return false, "wechat_public_key_invalid" end
    return true, ""
end
function M.request(c, method, target, body, raw_result, allow_refund_not_found)
    M.validate(c); body = body or ""
    local timestamp, nonce = tostring(U.now().unix), U.value("random.bytes", {size = 16, encoding = "hex"})
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem,
        data = method .. "\n" .. target .. "\n" .. timestamp .. "\n" .. nonce .. "\n" .. body .. "\n", encoding = "base64"})
    local authorization = 'WECHATPAY2-SHA256-RSA2048 mchid="' .. c.merchant_id .. '",nonce_str="' .. nonce .. '",timestamp="' .. timestamp .. '",serial_no="' .. c.merchant_serial_number .. '",signature="' .. signature .. '"'
    local r = U.call("https.request", {method = method, url = "https://api.mch.weixin.qq.com" .. target, body = body,
        headers = {Authorization = authorization, Accept = "application/json", ["Content-Type"] = "application/json", ["Wechatpay-Serial"] = c.public_key_id}})
    M.verify(c, r.headers, r.body)
    if allow_refund_not_found and r.status == 404 then
        assert(U.decode(r.body).code == "RESOURCE_NOT_EXISTS", "unrecognized WeChat refund absence response")
        return {notFound = true}
    end
    assert(type(r.status) == "number" and r.status >= 200 and r.status < 300, "provider outcome unknown: HTTP failure")
    if raw_result then return r.body end
    if r.body == "" then return {} end
    return U.decode(r.body)
end
function M.notification(c, p)
    assert(p.method == "POST", "WeChat notification requires POST")
    M.validate(c)
    local body = U.unbase64(U.required(p.bodyBase64))
    M.verify(c, p.headers, body)
    local envelope = U.decode(body)
    assert(type(envelope.resource) == "table" and envelope.resource.algorithm == "AEAD_AES_256_GCM", "unsupported notification encryption")
    local r = envelope.resource
    local plain = U.value("crypto.aes_gcm_decrypt", {key = c.api_v3_key, nonce = r.nonce,
        associatedData = r.associated_data or "", ciphertext = r.ciphertext})
    return U.decode(plain), envelope.event_type
end
return M
