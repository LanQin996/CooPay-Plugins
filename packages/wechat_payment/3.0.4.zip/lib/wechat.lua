local U = require("lib.util")
local M = {}
local function prepare_pem_credentials(c)
    for _, field in ipairs({"private_key_pem", "public_key_pem"}) do
        local value = c[field]
        if type(value) == "string" then
            local begin_start = string.find(value, "-----BEGIN ", 1, true)
            if begin_start == 1 then
                local label_end = string.find(value, "-----", 12, true)
                if label_end then
                    local label = string.sub(value, 12, label_end - 1)
                    local ending = "-----END " .. label .. "-----"
                    local finish = string.find(value, ending, label_end + 5, true)
                    if finish then
                        local suffix = string.sub(value, finish + #ending)
                        local extra = false
                        for i = 1, #suffix do if string.byte(suffix, i) > 32 then extra = true; break end end
                        if not extra then
                            local compact = {}
                            local body = string.sub(value, label_end + 5, finish - 1)
                            for i = 1, #body do
                                local byte = string.byte(body, i)
                                if byte > 32 then compact[#compact + 1] = string.sub(body, i, i) end
                            end
                            local encoded = table.concat(compact)
                            if #encoded > 0 then
                                local lines = {}
                                for i = 1, #encoded, 64 do lines[#lines + 1] = string.sub(encoded, i, i + 63) end
                                c[field] = "-----BEGIN " .. label .. "-----\n" .. table.concat(lines, "\n") .. "\n" .. ending
                            end
                        end
                    end
                end
            end
        end
    end
end
function M.validate(c)
    prepare_pem_credentials(c)
    for _, k in ipairs({"merchant_id", "appid", "public_key_id", "public_key_pem", "private_key_pem", "merchant_serial_number", "api_v3_key"}) do U.required(c[k], k .. " required") end
    assert(#c.api_v3_key == 32, "API v3 key must have 32 bytes")
end
function M.verify(c, headers, body)
    local serial = U.header(headers, "Wechatpay-Serial")
    local timestamp = U.header(headers, "Wechatpay-Timestamp")
    local nonce = U.header(headers, "Wechatpay-Nonce")
    local signature = U.header(headers, "Wechatpay-Signature")
    assert(serial == c.public_key_id, "untrusted WeChat signing key")
    U.required(timestamp); U.required(nonce); U.required(signature)
    local ts = tonumber(timestamp)
    assert(ts and math.abs(U.now().unix - ts) <= 300, "expired WeChat signature")
    assert(U.value("crypto.rsa_verify", {algorithm = "sha256", publicKey = c.public_key_pem,
        data = timestamp .. "\n" .. nonce .. "\n" .. body .. "\n", signature = signature, encoding = "base64"}) == true, "invalid WeChat signature")
end
function M.check(c)
    prepare_pem_credentials(c)
    for _, field in ipairs({"merchant_id", "appid", "public_key_id", "public_key_pem", "private_key_pem", "merchant_serial_number", "api_v3_key"}) do
        if type(c[field]) ~= "string" or #c[field] == 0 or #c[field] > 32768 then
            return false, "missing_" .. field
        end
    end
    if #c.api_v3_key ~= 32 then return false, "invalid_api_v3_key_length" end
    if string.find(c.public_key_pem, "-----BEGIN CERTIFICATE-----", 1, true) then
        return false, "wechat_public_key_is_certificate"
    end
    if string.find(c.private_key_pem, "-----BEGIN CERTIFICATE-----", 1, true) then
        return false, "merchant_private_key_is_certificate"
    end
    if string.find(c.private_key_pem, "-----BEGIN ENCRYPTED PRIVATE KEY-----", 1, true) then
        return false, "merchant_private_key_encrypted"
    end
    if string.find(c.private_key_pem, "-----BEGIN EC PRIVATE KEY-----", 1, true) then
        return false, "merchant_private_key_not_rsa"
    end
    local key_check = U.call("crypto.rsa_private_key_validate", {privateKey = c.private_key_pem})
    if not key_check.valid then return false, key_check.diagnosticCode or "merchant_private_key_invalid" end
    local ok, signature = pcall(U.value, "crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem,
        data = "CooPay plugin key validation", encoding = "base64"})
    if not ok then return false, "merchant_private_key_invalid" end
    -- The merchant and platform keys are different. The boolean is irrelevant;
    -- completing this operation proves the platform public key parsed safely.
    ok = pcall(U.value, "crypto.rsa_verify", {algorithm = "sha256", publicKey = c.public_key_pem,
        data = "CooPay plugin key validation", signature = signature, encoding = "base64"})
    if not ok then return false, "wechat_public_key_invalid" end
    return true, ""
end
function M.request(c, method, target, body, raw_result, allow_refund_not_found)
    M.validate(c); body = body or ""
    local timestamp, nonce = tostring(U.now().unix), U.value("random.bytes", {size = 16, encoding = "hex"})
    local signature = U.value("crypto.rsa_sign", {algorithm = "sha256", privateKey = c.private_key_pem,
        data = method .. "\n" .. target .. "\n" .. timestamp .. "\n" .. nonce .. "\n" .. body .. "\n", encoding = "base64"})
    local authorization = 'WECHATPAY2-SHA256-RSA2048 mchid="' .. c.merchant_id .. '",nonce_str="' .. nonce .. '",timestamp="' .. timestamp .. '",serial_no="' .. c.merchant_serial_number .. '",signature="' .. signature .. '"'
    local r = U.call("https.request", {method = method, url = "https://api.mch.weixin.qq.com" .. target, body = body,
        headers = {Authorization = authorization, Accept = "application/json", ["Content-Type"] = "application/json", ["Wechatpay-Serial"] = c.public_key_id}})
    M.verify(c, r.headers, r.body)
    if allow_refund_not_found and r.status == 404 then
        assert(U.decode(r.body).code == "RESOURCE_NOT_EXISTS", "unrecognized WeChat refund absence response")
        return {notFound = true}
    end
    assert(type(r.status) == "number" and r.status >= 200 and r.status < 300, "provider outcome unknown: HTTP failure")
    if raw_result then return r.body end
    if r.body == "" then return {} end
    return U.decode(r.body)
end
function M.notification(c, p)
    assert(p.method == "POST", "WeChat notification requires POST")
    M.validate(c)
    local body = U.unbase64(U.required(p.bodyBase64))
    M.verify(c, p.headers, body)
    local envelope = U.decode(body)
    assert(type(envelope.resource) == "table" and envelope.resource.algorithm == "AEAD_AES_256_GCM", "unsupported notification encryption")
    local r = envelope.resource
    local plain = U.value("crypto.aes_gcm_decrypt", {key = c.api_v3_key, nonce = r.nonce,
        associatedData = r.associated_data or "", ciphertext = r.ciphertext})
    return U.decode(plain), envelope.event_type
end
return M
